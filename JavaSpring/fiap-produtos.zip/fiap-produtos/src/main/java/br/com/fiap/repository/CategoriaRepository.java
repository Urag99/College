package br.com.fiap.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;

import br.com.fiap.model.CategoriaModel;
import br.com.fiap.model.ProdutoModel;

@Component
public class CategoriaRepository {
	
	private static final String GET_CATEGORIAS_PRODUTOS = "SELECT " + 
															"    C.ID_CATEGORIA, " + 
															"    C.NOME_CATEGORIA, " + 
															"    P.ID, " + 
															"    P.NOME " + 
															"FROM " + 
															"    TB_CATEGORIA C INNER JOIN TB_PRODUTO P ON P.ID_CATEGORIA = C.ID_CATEGORIA " + 
															"ORDER BY " + 
															"    C.NOME_CATEGORIA ";

	@Autowired
	public JdbcTemplate jdbcTemplate;

	public CategoriaRepository() {
	}

	public List<CategoriaModel> getProductsByCategories() {
		List<CategoriaModel> categorias = jdbcTemplate.query(GET_CATEGORIAS_PRODUTOS,
				new ResultSetExtractor<List<CategoriaModel>>() {

					public List<CategoriaModel> extractData(ResultSet rs) throws SQLException {
						Map<Long, CategoriaModel> categorias = new HashMap<Long, CategoriaModel>();

						while (rs.next()) {
							Long categoriaId = rs.getLong("ID_CATEGORIA");

							CategoriaModel categoriaModel = categorias.get(categoriaId);
							if (categoriaModel == null) {
								categoriaModel = new CategoriaModel(categoriaId, rs.getString("NOME_CATEGORIA"), new ArrayList<ProdutoModel>());
								categorias.put(categoriaId, categoriaModel);
							}

							ProdutoModel produtoModel = new ProdutoModel(rs.getLong("id"), rs.getString("nome"));

							categoriaModel.getProdutos().add(produtoModel);
						}

						return new ArrayList<CategoriaModel>(categorias.values());
					}
				});

		return categorias;
	}
	
	public List<CategoriaModel> lista(){
		List<CategoriaModel> categorias = jdbcTemplate.query("Select * from tb_categoria", new BeanPropertyRowMapper<CategoriaModel>(CategoriaModel.class));
		
		return categorias;
	}
	
	public void deletar(long id) {
		this.jdbcTemplate.update("DELETE FROM TB_CATEGORIA WHERE ID = ?", id);
	}
	
	public CategoriaModel get(long id) {

		CategoriaModel categoria = this.jdbcTemplate.queryForObject("SELECT * FROM TB_CATEGORIA WHERE ID = ?", new BeanPropertyRowMapper<CategoriaModel>(CategoriaModel.class), id);
		return categoria;
	}
		
	
	public void atualizar(CategoriaModel categoriaModel) {
		this.jdbcTemplate.update("UPDATE TB_CATEGORIA SET NOME_CATEGORIA = ? WHERE ID_CATEGORIA = ?",
				categoriaModel.getNomeCategoria(),
				categoriaModel.getIdCategoria());
	}
}
