package br.com.fiap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.fiap.model.CategoriaModel;
import br.com.fiap.repository.CategoriaRepository;

@Controller
@RequestMapping("/categoria")
public class CategoriaController {

	@Autowired
	public CategoriaRepository categoriaRepository;
	
	@GetMapping("/relatorio")
	public String getProductsByCategories(Model model) {
		model.addAttribute("categorias", categoriaRepository.getProductsByCategories());
		return "categorias-relatorio";
	}
	
	
	@GetMapping
	public String lista(Model model) {
		List<CategoriaModel> categorias = categoriaRepository.lista();
		
		model.addAttribute("categorias", categorias);
		
		return categorias;
		
	}
	
}
