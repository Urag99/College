package br.fiap.servlet;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.fiap.desque.Produto;
import br.fiap.desque.ProdutoDAO;

/**
 * Servlet implementation class Servlet
 */
@WebServlet("/controle")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String aux = request.getParameter("enviar");
		
		if(aux == "Cadastrar") {
		String codigo = request.getParameter("codigo");
		String nome = request.getParameter("produto");
		String preco = request.getParameter("preco");
		String usado = request.getParameter("usado");
		String[] data = request.getParameter("data").split("-");
		Date datab = new Date(Integer.parseInt(data[0]), Integer.parseInt(data[1]), Integer.parseInt(data[2]));
		
		int codigob = 0;
		double precob = 0;
		
			try {
				ProdutoDAO dao = new ProdutoDAO();
				codigob = Integer.parseInt(codigo);
				precob = Double.parseDouble(preco);
				Produto produto = new Produto(codigob, nome, precob, usado, datab);
				dao.Inserir(produto);
			} catch (Exception e) {
			// TODO: handle exception
			}
		}
	}

}
