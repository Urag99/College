package br.fiap.desque;
import br.fiap.conexao.*;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ProdutoDAO {
	
	private Connection connection;
	private String sql;
	private PreparedStatement p;
	ResultSet rs;
	

	public ProdutoDAO() {
		connection = conexao.getConnection();
	}
	
	
	public void Inserir(Produto produto) {
		sql = "Insert into tb_produto values= (?,?,?,?,?)";
		try {
			p = connection.prepareStatement(sql);
			p.setInt(1, produto.getCodigo());
			p.setString(2, produto.getProduto());
			p.setDouble(3, produto.getPreco());
			p.setString(4, produto.getUsado());
			p.setDate(5, produto.getDate());
			p.execute();
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public boolean Pesquisar(int codigo) {
		boolean achou = false;
		sql = "Select * from tb_produto where codigo = ?";
		try {
			p = connection.prepareStatement(sql);
			p.setInt(1, codigo);
			rs = p.executeQuery();
			achou = rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return achou;
	}
	
		
	public List<Produto> listar(){
		List<Produto> lista = new ArrayList<>();
		sql = "Select * from tb_produto";
		try {
			p = connection.prepareStatement(sql);
			rs = p.executeQuery();
			while(rs.next()) {
				lista.add(new Produto(rs.getInt("codigo"), rs.getString("produto"), rs.getDouble("preco"), rs.getString("usado"), rs.getDate("inicio")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return lista;
	}
}
