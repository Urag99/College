package br.fiap.desque;

import java.sql.Date;

public class Produto {
	int codigo;
	String produto;
	double preco;
	String usado;
	Date date;
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getProduto() {
		return produto;
	}
	public void setProduto(String produto) {
		this.produto = produto;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public String getUsado() {
		return usado;
	}
	public void setUsado(String usado) {
		this.usado = usado;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	public Produto(int codigo, String produto, double preco, String usado, Date date) {
		super();
		this.codigo = codigo;
		this.produto = produto;
		this.preco = preco;
		this.usado = usado;
		this.date = date;
	}
	
	
	
	
	
}
