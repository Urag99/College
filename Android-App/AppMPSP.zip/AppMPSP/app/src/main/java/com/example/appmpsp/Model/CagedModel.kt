package com.example.appmpsp.Model


class CagedModel {

    var IdCaged : Int = 0;
    var CTPS : String = "";
    var SituacaoPis : String = "";
    var Nacionalidade : String = "";
    var GrauDeInstituicao : String = "";
    var PessoaComDeficiencia : String = "";
    var DtNascimento : String = "";
    var Sexo : String = "";
    var Raca : String = "";
    var CEP : String = "";

}