package com.example.appmpsp.Retrofit

import android.telecom.Call
import com.example.appmpsp.Model.CagedModel
import retrofit2.http.GET
import retrofit2.http.Path

interface CagedService {
    @GET("api/Caged/{id}")
    fun list(@Path("id") id: Int): Call
}