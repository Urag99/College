package com.example.appmpsp.Model



class ArpenpModel{
    var idArpenp : Int = 0;
    var NomeConjuge : String = "";
    var Dtcasamento : String = "";
    var Matricula : Int = 0;
    var Dtentrada : String = "";
    var Dtregistro : String = "";
    /*acervo
    numero_livro
    numero_folha
    numero_registro
    tipo_livro
    cartorio_registro
    numero_cns
    UF*/


}