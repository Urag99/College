package com.example.appmpsp.Activities

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.appmpsp.R
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        usuario.setText("admin")
        senha.setText("admin")


        btlogin.setOnClickListener(View.OnClickListener {

            var intent = Intent(this, insertActivity::class.java)

            if(usuario.text.toString().equals("admin") && senha.text.toString().equals("admin")){
                startActivity(intent)
            }else{
                Toast.makeText(this,"Login inválido!",Toast.LENGTH_SHORT).show()
            }


        })
    }
}
