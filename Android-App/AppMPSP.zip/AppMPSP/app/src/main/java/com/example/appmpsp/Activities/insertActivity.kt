package com.example.appmpsp.Activities


import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import com.example.appmpsp.R
import kotlinx.android.synthetic.main.activity_insert.*

const val ndoc = "com.example.nac.doc"
const val tipo = "com.example.nac.tipo"
const val arp = "com.example.nac.arp"
const val cad = "com.example.nac.cad"
const val cag = "com.example.nac.cag"


class insertActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insert)

        val intent = Intent(this, listagemActivity::class.java)


        val numerodoc = findViewById<EditText>(R.id.documento);
        var nrodocumento : String;


        //-----------------SPINNER-----------------//

        val documentos = arrayOf<String>("CPF", "CNPJ")
        val spinner = findViewById(R.id.spinner_tipo_documento) as Spinner;
        var tipodocumento: String = "";




        var adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, documentos)
        spinner.adapter = adapter

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                tipodocumento = spinner.getItemAtPosition(position).toString();
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }
        }



        //-----------------CHECK BOX-----------------//


        val chkArpenp = findViewById<CheckBox>(R.id.id_arpenp);
        var arpenp : String;
        val chkCadesp = findViewById<CheckBox>(R.id.id_cadesp);
        var cadesp : String ;
        val chkCaged = findViewById<CheckBox>(R.id.id_caged);
        var caged : String;


        chkArpenp.setOnClickListener(View.OnClickListener {
            if(chkArpenp.isChecked){
               arpenp = "true";

                intent.apply {
                    intent.putExtra(arp, arpenp)
                }

            }else{
                arpenp = "false";
                intent.apply {
                    intent.putExtra(arp, arpenp)
                }
            }

        })


        chkCadesp.setOnClickListener(View.OnClickListener {
            if(chkCadesp.isChecked){
                cadesp = "true";
                intent.apply {
                    intent.putExtra(cad, cadesp)
                }
            }else{
                cadesp = "false";
                intent.apply {
                    intent.putExtra(cad, cadesp)
                }
            }

        })



        chkCaged.setOnClickListener(View.OnClickListener {
            if(chkCaged.isChecked){
                caged = "true";
                intent.apply {
                    intent.putExtra(cag, caged)
                }
            }else{
                caged = "false";
                intent.apply {
                    intent.putExtra(cag, caged)
                }
            }
        })



        //-----------------BOTAO-----------------//

        btBuscar.setOnClickListener {
            nrodocumento = numerodoc.text.toString();

            if(tipodocumento.equals("CPF")){
                if(nrodocumento.length < 0){
                    Toast.makeText(this,"CPF inválido", Toast.LENGTH_SHORT).show();
                } else{
                    intent.apply {
                        putExtra(ndoc, nrodocumento)
                    }

                    intent.apply {
                        putExtra(tipo, tipodocumento)
                    }

                    startActivity(intent);
                }

            }else{
                if(nrodocumento.length < 0) {
                    Toast.makeText(this,"CNPJ inválido", Toast.LENGTH_SHORT).show();
                }else{
                    intent.apply {
                        putExtra(ndoc, nrodocumento)
                    }

                    intent.apply {
                        putExtra(tipo, tipodocumento)
                    }

                    startActivity(intent);
                }
            }
        }



    }

}
