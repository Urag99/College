package com.example.appmpsp.Model


class CadespModel {

    var IdCadesp : Int = 0;
    var Ie : String = ""
    var NomeEmpresarial : String = "";
    var Drt : String = "";
    var Situacao : String = "";
    var DtInscricao : String = "";
    var RegimeEstadual : String = "";
    var PostoFiscal : String = "";
}
