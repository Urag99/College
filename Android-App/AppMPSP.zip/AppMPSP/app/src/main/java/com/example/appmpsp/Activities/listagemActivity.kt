package com.example.appmpsp.Activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import com.example.appmpsp.Model.CagedModel
import com.example.appmpsp.R
import com.example.appmpsp.Retrofit.RetrofitInitializer

class listagemActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listagem)

       /* val numerodoc = intent.getStringExtra(ndoc)
        val tipodoc = intent.getStringExtra(tipo)
        val arpenp  = intent.getStringExtra(arp)
        val caged  = intent.getStringExtra(arp)
        val cadesp  = intent.getStringExtra(arp)


        testedoc.setText(numerodoc).toString();
        testespinner.setText(tipodoc).toString();

        if(arpenp.equals("true")){
            testechk.isChecked = true;
        }*/

        RetrofitInitializer();

    }
}
