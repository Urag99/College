﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace aula02
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class SaldoPage : ContentPage
	{
		public SaldoPage ()
		{
			InitializeComponent ();
		}

        public async void BotaoVoltarClicked(Object o, EventArgs e)
        {
            await Navigation.PopAsync();
        }

        public async void BotaoSairClicked(Object o, EventArgs e)
        {
            await Navigation.PopToRootAsync();
        }

    }
}