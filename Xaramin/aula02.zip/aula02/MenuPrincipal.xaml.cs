﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace aula02
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class MenuPrincipal : ContentPage
	{
		public MenuPrincipal ()
		{
			InitializeComponent ();
		}

  
        public async void BotaoSaldoClicked(object o, EventArgs e)
        {
            await Navigation.PushAsync(new SaldoPage());
        }

        public async void BotaoPerfilClicked(object o, EventArgs e)
        {
            await Navigation.PushAsync(new PerfilPage());
        }

        public async void BotaoSairClicked(object o, EventArgs e)
        {
            await Navigation.PopAsync();
        }



    }
}