﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace aula02
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class LoginPage : ContentPage
	{
		public LoginPage ()
		{
			InitializeComponent ();

            //BotaoLogin.Clicked += BotaoLoginClicked;

		}

        public async void BotaoLoginClicked(Object o, EventArgs e)
        {
            await Navigation.PushAsync(new MenuPrincipal());
        }

        /*public void BotaoLoginClicked(Object o, EventArgs e )
        {
            DisplayAlert("Título", "Ola Fiap!", "Fechar");
        }*/

       /* private void BotaoSairClicked(object sender, EventArgs e)
        {
            DisplayAlert("Título", "Saindo...", "Ok");
        }*/
    }



}