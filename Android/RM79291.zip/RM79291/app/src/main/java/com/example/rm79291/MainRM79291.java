package com.example.rm79291;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MainRM79291 extends AppCompatActivity {
    private EditText nomeRM79291;
    private EditText emailRM79291;
    private CheckBox enviarNotificacaoRM79291;
    private TextView nascimentoRM79291;

    private RadioGroup idadeRM79291;

    private RadioButton rb;
   // private RadioButton Ate12RM79291;
   // private RadioButton Entre13e25RM79291;
   // private RadioButton Entre25e60RM79291;


    private Spinner estadoRM79291;
    private Button cadastrarRM79291;
    private Button visualizarRM79291;
    private ArrayList<CadastroRM79291> cadastros;
    DatePickerDialog datePickerDialog;
    Calendar calendar;
    Date nascimentoData = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nomeRM79291 = findViewById(R.id.nomeRM79291);
        emailRM79291 = findViewById(R.id.emailRM79291);
        enviarNotificacaoRM79291 = findViewById(R.id.enviarEmailRM79291);
        nascimentoRM79291 = findViewById(R.id.nascimentoRM79291);

        idadeRM79291 = findViewById(R.id.idadeRM79291);
       // Ate12RM79291 = findViewById(R.id.Ate12RM7291);
        //Entre13e25RM79291 = findViewById(R.id.Entre13e25RM79291);
        //Entre25e60RM79291 = findViewById(R.id.Entre25e60AnosRM79291);

        estadoRM79291 = findViewById(R.id.estadoRM79291);
        cadastrarRM79291 = findViewById(R.id.cadastrarRM79291);
        visualizarRM79291 = findViewById(R.id.visualizarRM79291);

        calendar = Calendar.getInstance();
        datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int month, int dayOfMonth) {
                        //capturar data selecionada pelo usuário e imprimir no textview
                        Calendar dataSelecionada = Calendar.getInstance();
                        dataSelecionada.set(year, month, dayOfMonth);
                        nascimentoData = dataSelecionada.getTime();

                        SimpleDateFormat format =
                                new SimpleDateFormat("dd/MM/yyyy");
                        nascimentoRM79291.setText(format.format(dataSelecionada.getTime()));


                    }
                }, calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));

        nascimentoRM79291.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePickerDialog.show();
            }
        });

        cadastrarRM79291.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nomeRM79291.getText().toString();
                String email = emailRM79291.getText().toString();
                boolean notificacao = enviarNotificacaoRM79291.isChecked();
                Date nascimento = nascimentoData;
                int posicao = idadeRM79291.getCheckedRadioButtonId();

                if("".equals(nome) || "".equals(email) || posicao == 0 || nascimento == null) {
                    Toast.makeText(MainRM79291.this,
                            "Campos vazios",
                            Toast.LENGTH_SHORT).show();
                } else {
                    rb = (RadioButton) findViewById(posicao);
                    String idade = rb.getText().toString();

                    CadastroRM79291 cad;
                    cad = new CadastroRM79291(nome, email, notificacao, nascimento, idade);
                    cadastros.add(cad);

                }

            }
        });


        visualizarRM79291.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainRM79291.this,
                        visualizarRM79291.class);
                intent.putExtra("visualizar", cadastros);
                startActivity(intent);

            }
        });


    }
}
