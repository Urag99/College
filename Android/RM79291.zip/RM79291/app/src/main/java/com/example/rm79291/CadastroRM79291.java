package com.example.rm79291;

import java.io.Serializable;
import java.util.Date;

public class CadastroRM79291 implements Serializable {

    private String nomeRM79291;
    private String emailRM79291;
    private boolean enviarNotificacaoRM79291;
    private Date nascimentoRM79291;
    private String idadeRM79291;
    private String estadoRM79291;


    public CadastroRM79291(String nomeRM79291, String emailRM79291, boolean receberNotificacaoRM79291, Date nascimentoRM79291, String idadeRM79291) {
        this.nomeRM79291 = nomeRM79291;
        this.emailRM79291 = emailRM79291;
        this.enviarNotificacaoRM79291 = receberNotificacaoRM79291;
        this.nascimentoRM79291 = nascimentoRM79291;
        this.idadeRM79291 = idadeRM79291;
    }

    public String getNomeRM79291() {
        return nomeRM79291;
    }

    public void setNomeRM79291(String nomeRM79291) {
        this.nomeRM79291 = nomeRM79291;
    }

    public String getEmailRM79291() {
        return emailRM79291;
    }

    public void setEmailRM79291(String emailRM79291) {
        this.emailRM79291 = emailRM79291;
    }

    public boolean isEnviarNotificacaoRM79291() {
        return enviarNotificacaoRM79291;
    }

    public void setEnviarNotificacaoRM79291(boolean enviarNotificacaoRM79291) {
        this.enviarNotificacaoRM79291 = enviarNotificacaoRM79291;
    }

    public Date getNascimentoRM79291() {
        return nascimentoRM79291;
    }

    public void setNascimentoRM79291(Date nascimentoRM79291) {
        this.nascimentoRM79291 = nascimentoRM79291;
    }

    public String getIdadeRM79291() {
        return idadeRM79291;
    }

    public void setIdadeRM79291(String idadeRM79291) {
        this.idadeRM79291 = idadeRM79291;
    }

    public String getEstadoRM79291() {
        return estadoRM79291;
    }

    public void setEstadoRM79291(String estadoRM79291) {
        this.estadoRM79291 = estadoRM79291;
    }
}
