package com.example.rm79291;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class AdapterRM79291 extends BaseAdapter {

    private Context context;
    private ArrayList<CadastroRM79291> cadastros;

    public AdapterRM79291(Context context, ArrayList<CadastroRM79291> cadastros) {
        this.context = context;
        this.cadastros = cadastros;
    }

    @Override
    public int getCount() { return cadastros.size(); }

    @Override
    public Object getItem(int position) {
        return cadastros.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View inflater = LayoutInflater.from(context).inflate(R.layout.activity_visualizar, parent, false);
        TextView nome = inflater.findViewById(R.id.nome);
        TextView email = inflater.findViewById(R.id.email);
        TextView notificacao = inflater.findViewById(R.id.notificacao);
        TextView nascimento = inflater.findViewById(R.id.nascimento);
        TextView idade = inflater.findViewById(R.id.idade);

        CadastroRM79291 cad = cadastros.get(position);

        nome.setText(cad.getNomeRM79291());
        email.setText(cad.getEmailRM79291());
        notificacao.setText(cad.getEmailRM79291());
        nascimento.setText(cad.getNascimentoRM79291());
        idade.setText(cad.getIdadeRM79291());


        return inflater;
    }

}
