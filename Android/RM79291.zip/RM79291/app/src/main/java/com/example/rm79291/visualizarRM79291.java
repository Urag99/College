package com.example.rm79291;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

public class visualizarRM79291 extends AppCompatActivity {

    private ListView lista;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);
        lista = findViewById(R.id.lista);
        ArrayList<CadastroRM79291> cadastros = new ArrayList<CadastroRM79291>();

        cadastros = (ArrayList<CadastroRM79291>)getIntent().getExtras().get("visualizar");

        AdapterRM79291 adapter = new AdapterRM79291(visualizarRM79291.this, cadastros);

        lista.setAdapter(adapter);
    }

}

