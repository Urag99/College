package com.example.logonrmlocal.appcomlistview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView lista;
    private ArrayList<Funcionario> funcionarios;
    private FuncionarioAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lista = findViewById(R.id.lista);
        funcionarios = new ArrayList<Funcionario>();
        funcionarios.add(new Funcionario("Func 1", "A"));
        funcionarios.add(new Funcionario("Func 2", "B"));
        funcionarios.add(new Funcionario("Func 3", "C"));
        funcionarios.add(new Funcionario("Func 4", "D"));
        adapter = new FuncionarioAdapter(MainActivity.this, funcionarios);
        lista.setAdapter(adapter);
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Funcionario funcionario = funcionarios.get(position);
            }
        });
    }
}

